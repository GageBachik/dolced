<?php
require 'include.php';
session_start();
error_reporting(0);

	$selectBets = $dbc->query("SELECT * FROM `bets` WHERE `status` = 'Paid' ORDER BY `bid` DESC LIMIT 30");
?>
<style type="text/css">
#hash_text {
	font-size: 3.8px;
}
</style>
<table class="table table-striped table-bordered table-hover">
                <thead>
                  <tr>
                    <th>Bet Number</th>
                    <th>Amount</th>
                    <th>Send Address</th>
                    <th>Time Created</th>
					<th>Time Expires</th>
					<th>Your Chance</th>
					<th>Payout Multiplier</th>
					<th>Final Profit</th>
					<th>Server Hash</th>
                  </tr>
                </thead>
                <tbody>
				<?php while($BetsArray = $selectBets->fetch()) { ?>
                  <tr <?php if($BetsArray['amount'] > 0.5) { echo 'class="warning"'; } ?>>
				  <td><?php echo $BetsArray['bid']; ?></td> 
				  <td><?php echo $BetsArray['amount']; ?></td> 
				  <td><?php echo $BetsArray['deposit_address']; ?></td> 
				  <td><?php echo date('m/d/Y - H:i:s', $BetsArray['time_created']); ?></td> 
				  <td><?php echo date('m/d/Y - H:i:s', $BetsArray['time_expires']); ?></td> 
				  <td><?php echo (100 - $BetsArray['win_chance']); ?></td> 
				  <td><?php echo 100 / (100 - $BetsArray['win_chance']); ?></td> 
				  <td><?php echo $BetsArray['amount']*100 / (100 - $BetsArray['win_chance']); ?></td> 
				  <td><a class="hash" data-container="body" data-toggle="popover" data-placement="right">Click here for Server Hash</a></td>
                  </tr>
				  			  <script type="text/javascript">
			  $(function() {
				$('.hash').popover({
					trigger: 'click',
					html: true,
					placement: 'right',
					content: '<?php echo '<span id="hash_text">' . hash('sha512', $BetsArray['number'] . '-' . $_SESSION['client_seed']) . '</span>';?>'
				});
			  });
			  </script>
				<?php } ?>
                </tbody>
              </table>