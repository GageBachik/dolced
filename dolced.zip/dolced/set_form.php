<?php
session_start();

	if(strlen($_POST['payout_address']) == 34) {
		$_SESSION['payout_address'] = $_POST['payout_address'];
		echo 'Your address has been set.  We hope you enjoy the Dolced experience.';
	} else {
		echo 'There was an issue with setting your address.  Make sure it\'s correct.';
	}

?>