<?php
session_start();

	if(!isset($_SESSION['client_seed']) && !isset($_POST['client_seed'])) {
		$_SESSION['client_seed'] = substr(md5(uniqid(mt_rand(), true)), 0, 10);
			echo $_SESSION['client_seed'];
	} else {
		echo $_SESSION['client_seed'];
	}
?>