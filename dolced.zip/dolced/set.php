<?php
session_start();
error_reporting(0);

  if(!isset($_SESSION['payout_address'])) {

?>
  <div class="modal fade" id="set" tabindex="" role="dialog" aria-labelledby="myModalLabel" aria-hidden="false">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">Welcome to Dolced.</h4>
        </div>
        <div class="modal-body">
          <p>Welcome to Dolced.
          We are striving to provide the best possible framework for bettor-run
          Bitcoin gambling.  All bets are submitted through our systems and can
          be bet by you or anyone else that visits the site.  We take a mere 5%
          commission on all bets to afford to run the site and make sure it's secure.
          Whether you plan on using the site or not, please enter a payout address:</p>
        
        <form action="set_form.php" method="POST" id="set_form">
        <label for="client">Your Bitcoin Address</label>
        <input type="text" class="form-control" name="payout_address" id="payout_address" placeholder="Your 34 character Bitcoin address"><br />
        <span id="set_return"></span>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-primary" id="set_save">Save Address</button>
        </div>
        </form>
      </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
  </div><!-- /.modal -->

<?php } ?>