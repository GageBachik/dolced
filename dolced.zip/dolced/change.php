<?php
session_start();

	if(strlen(@$_POST['client_seed']) == 10) {
		unset($_SESSION['client_seed']);
		@$_SESSION['client_seed'] = @$_POST['client_seed'];
		
			echo '<b>Your client seed has been updated to what you have entered.<br /><br /></b>';
	} else {
		echo '<b>There was an error updating your client seed.  Check to make sure it\'s 10 characters<br /><br /></b>';
	}
?>