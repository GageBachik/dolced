<?php
		$real_secret = 'sc3r4t3c0d'; //Set a secret and don't give it to anyone.
		$input_address = @$_GET['input_address']; //Do not touch this.
		$amount_btc	= @$_GET['value'] / 100000000; //Do not touch this.

			if(@$_GET['secret'] == $real_secret && $_GET['confirmations'] >= 1) {
				$update = $dbc->prepare('UPDATE bets SET status = "Paid" WHERE deposit_address = ?');
				$update->execute(array($input_address));

					$check_pending = $dbc->prepare('SELECT * FROM bets WHERE deposit_address = ?');
					$check_pending->execute(array($input_address));
					$status = $check_pending->fetch();

						if($status['status'] == 'Paid') {
							$update_finished = $dbc->prepare('UPDATE bets SET status = "Finished" WHERE deposit_address = ?');
							$update_finished->execute(array($input_address));

							if($status['number'] <= $status['win_chance']) {

									$payout_bet = file_get_contents('https://inputs.io/api?key=e1dae162395a69bc185698557f88e3d4&action=send&address=' . $status['sender_address'] . '&amount=' . $amount_btc * 1.95 . '&note='. $input_address . '&pin=2194');
									
									/*
									*	Make an inputs.io account and fill in your API Key from the security tab.
									*	Handle the API Key with caution!  If someone gets it, they can steal your bettor's coins.
									*	When you register with inputs.io, you set a 4-digit PIN.  Enter that PIN at the end in place of 0000.
									*/
							} else {

									$payout_bet = file_get_contents('https://inputs.io/api?key=e1dae162395a69bc185698557f88e3d4&action=send&address=' . $_SESSION['payout_address'] . '&amount=' . $amount_btc * 1.95 . '&note='. $input_address . '&pin=2194');
									
									/*
									*	Make an inputs.io account and fill in your API Key from the security tab.
									*	Handle the API Key with caution!  If someone gets it, they can steal your bettor's coins.
									*	When you register with inputs.io, you set a 4-digit PIN.  Enter that PIN at the end in place of 0000.
									*/
							}

						}
			}
?>