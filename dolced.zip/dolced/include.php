<?php

$dbc = new PDO('mysql:host=localhost;dbname=dolced', 'root', '');

?>