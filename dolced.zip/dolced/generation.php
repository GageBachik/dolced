<?php

$real_secret = '73nc65xb29';  //Set a unique secret and never give it to anyone.  They can attack the site if they have it.

$my_address = '12rRomcGQr2WRe8cuKp5C6mLnyBHvaVv8B';  //Your bitcoin address on your inputs.io wallet.

$my_callback_url = 'http://dolced.com/blockchain_callback.php?secret=' . $real_secret;  //Replace yoursiteurl.com with the site URL.

$root_url = 'https://blockchain.info/api/receive';

$parameters = 'method=create&callback='. urlencode($my_callback_url) . '&address=' . $my_address;

$response = file_get_contents($root_url . '?' . $parameters);

$object = json_decode($response);

?>