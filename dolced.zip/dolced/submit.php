<?php
require 'include.php';
require 'generation.php';

	$amount = @$_POST['amount'];
	$chance = @$_POST['chance'];
	$multiplier = 100/$chance;
	$when = @$_POST['when'];
	$number = rand(0, 10000)/100;
	$sender_address = $_POST['sender_address'];
	
		if(isset($amount, $chance, $multiplier, $sender_address)) {
			if(is_numeric($amount) && is_numeric($chance) && strlen($sender_address) == 34) {
				if($amount > 0 && $chance >= 1 && $chance <= 99) {
					$insertBet = $dbc->prepare("INSERT INTO `bets`(`number`, `deposit_address`, `time_created`, `time_paid`, 
																   `win_chance`, `amount`, `profit`, `multiplier`,
																   `time_expires`, `sender_address`, `status`) VALUES (?, ?,
																   ?, ?, ?, ?, ?, ?, ?, ?, ?)");
					$insertBet->execute(array($number, $object->input_address, time(), 0, $chance, $amount, $amount*$multiplier-$amount, $multiplier, time()+86400, $sender_address, 'Pending'));
					
					echo '<div class="alert alert-success">Your bet has been added to the queue as pending.  Pay to <b>' . $object->input_address . '</b> to make it available to other bettors.  Unpaid bets will be deleted.</div>';
					
				} else {
					echo '<div class="alert alert-danger">The Win Chance must be between 0.01 and 99.99.  The amount must also be greater than zero.  Try again.</div>';
				}
			} else {
				echo '<div class="alert alert-danger">It looks like you didn\'t enter one of the inputs.  Double-check that <b>all</b> inputs are entered.  The "when" option will default to the time you fill out the form.</div>';
			}
		}

		//Check if bets have been in the database for one day, if so they will be deleted.

		$select_all_bets = $dbc->prepare('SELECT time_created FROM bets');
		$select_all_bets->execute();
		$time_checker = $select_all_bets->fetch();

			if($time_checker['time_created'] == time()) {
				$time = time();
				$delete_bet = $dbc->prepare('DELETE FROM bets WHERE time_created = ?');
				$delete_bet->execute(array($time));
			}

?>