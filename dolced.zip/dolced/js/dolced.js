$('#submit_bet').click(function() {
	$.post( $('.submit_bet').attr('action'),
		$('.submit_bet :input').serializeArray(),
			function (data) {
				$('#submit_return').html(data);
	});
});

$('.submit_bet').submit(function() {
	return false;
});

$('#set_save').click(function() {
	$.post( $('#set_form').attr('action'),
		$('#set_form :input').serializeArray(),
			function (data) {
				$('#set_return').html(data);
	});
});

$('#set_form').submit(function() {
	return false;
});

$('#client_save').click(function() {
  $.post( $('#client_form').attr('action'),
    $('#client_form :input').serializeArray(),
      function (data) {
        $('#client_return').html(data);
  });
});

$('#client_form').submit(function() {
  return false;
});

$('#set').modal({
    show: 'true',
    backdrop: 'static'
});

$('.current_bets').load('./current_bets.php');

$('#new_bets').click(function() {
	$('.current_bets').load('./current_bets.php');
});

  function updateValues() {
      // Grab all the value just incase they're needed.
      var chance = $('#chance').val();
      var bet = $('#amount').val();
      var pay = $('#multiplier').val();
      var profit = $('#profit').val();

      // Calculate the new payout.
      pay = 100 / chance;


      // Calculate the new profit.
      profit = bet * pay - bet;

      // Set the new input values.
      $('#chance').val(chance);
      $('#bet').val(bet);
      $('#multiplier').val(pay);
      $('#profit').val(profit);
  }

  $('#chance').keyup(updateValues);
  $('#amount').keyup(updateValues);
  $('#multiplier').keyup(updateValues);
  $('#profit').keyup(updateValues);
  

	$.post('client.php', function(current) {
		$('#current_seed').html(current);
	});