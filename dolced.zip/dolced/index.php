<?php error_reporting(0); ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="shortcut icon" href="../../assets/ico/favicon.png">
	<style type="text/css"> #new_bets { cursor: pointer; } </style>

    <title>Dolced - Bitcoin Bettor-Run Casino</title>

    <!-- Bootstrap core CSS -->
    <link href="./css/bootstrap.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="navbar-static-top.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="../../assets/js/html5shiv.js"></script>
      <script src="../../assets/js/respond.min.js"></script>
    <![endif]-->
  </head>

  <body>

    <!-- Static navbar -->
    <div class="navbar navbar-default navbar-static-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="#">Dolced</a>
        </div>
        <div class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <li class="active"><a href="#">Home</a></li>
            <li><a href="#provable" data-toggle="modal">Provable</a></li>
			<li><a href="#">Archives</a></li>
			<li><a href="#">FAQs</a></li>
            <li><a href="#contact">Contact</a></li>
          </ul>
		  <ul class="nav navbar-nav pull-right">
			<li><a href="#">Site Partners</a></li>
		  </ul>
        </div><!--/.nav-collapse -->
      </div>
    </div>


    <div class="container">

      <!-- Main component for a primary marketing message or call to action -->
      <div class="jumbotron">
        <h2>Welcome to Dolced</h2>
        <p>Welcome to Dolced.  You can bet with no house-edge.</p>
        <p>We are able to run the site because we take small commissions that allow for safe betting.</p>
        <p>
          <a class="btn btn-lg btn-primary" href="../../components/#navbar">View our FAQs &raquo;</a>
        </p>
      </div>
		<h4>Submit a bet. <small>Once you've deposited the amount for your bet, it will be added to the queue.  To bet other players, view the table below.  Click the refresh button to see new bets.</small></h4><br />
		<form action="submit.php" method="POST" class="submit_bet">
			<div id="submit_return"></div>
				<div class="col-lg-2">
					<input type="text" class="form-control" placeholder="The Amount" name="amount" id="amount">
				</div>
				<div class="col-lg-2">
					<input type="text" class="form-control" placeholder="The Chance to Win" name="chance" id="chance">
				</div>
				<div class="col-lg-2">
					<input type="text" class="form-control" placeholder="Bet Multiplier" name="multiplier" id="multiplier">
				</div>
				<div class="col-lg-2">
					<input type="text" class="form-control" placeholder="Bet Profit" name="profit" id="profit">
				</div>
        <div class="col-lg-3">
          <button type="button" class="btn btn-primary" id="submit_bet">Submit Bet</button>&nbsp;&nbsp;
          <img src="http://puu.sh/4vmH4.png" id="new_bets" alt="submit"> 
        </div><br /><br />
        <div class="col-lg-4">
          <input type="text" class="form-control" placeholder="Your Bitcoin Address (to payout to)" name="sender_address">
        </div>
		</form>
	
	<br /><br /><br /><br />
	<h4>Or, alternatively... <small>Fulfill another bettor's bet that was submitted by them.  Send to the provided address and await results (nearly instant).  <a href="#">Click here</a> to view all pending bets.</h4><br />
              <div class="current_bets">
			  </div>

                </div>
           

    </div> <!-- /container -->
  <?php require 'set.php'; ?>
  <!-- Modal -->
  <div class="modal fade" id="provable" tabindex="" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
          <h4 class="modal-title">Your Provably Fair information.</h4>
        </div>
        <div class="modal-body">
          <p>You are assigned a unique "client seed" when you visit this website.
			  When you change your client seed, the results of any bets you participate
			  in are affected too.  We provide a system of provably fair to ensure the
			  safety of the bettors.  To change your seed, use the form below.</p>
			  
			  <form action="change.php" method="POST" id="client_form">
			  <span id="client_return"></span>
				<label for="client">Your Client Seed</label>
				<input type="text" class="form-control" name="client_seed" id="client" placeholder="10 characters, a-z, A-Z, 0-9."><br />
				Your current client seed is <b id="current_seed"></b>.
			  
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
          <button type="button" class="btn btn-primary" id="client_save">Save changes</button>
        </div>
				</form>
      </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
  </div><!-- /.modal -->
    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
	<script src="./js/bootstrap.min.js" type="text/javascript"></script>
	<script src="./js/dolced.js" type="text/javascript"></script>

  </body>
</html>