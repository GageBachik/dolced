-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Oct 17, 2013 at 04:23 AM
-- Server version: 5.5.27
-- PHP Version: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `dolced`
--

-- --------------------------------------------------------

--
-- Table structure for table `bets`
--

CREATE TABLE IF NOT EXISTS `bets` (
  `bid` int(11) NOT NULL AUTO_INCREMENT,
  `number` varchar(255) NOT NULL,
  `deposit_address` varchar(255) NOT NULL,
  `time_created` varchar(255) NOT NULL,
  `time_paid` varchar(255) NOT NULL,
  `win_chance` varchar(255) NOT NULL,
  `amount` varchar(255) NOT NULL,
  `profit` varchar(255) NOT NULL,
  `multiplier` varchar(255) NOT NULL,
  `time_expires` varchar(255) NOT NULL,
  `sender_address` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  PRIMARY KEY (`bid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `bets`
--

INSERT INTO `bets` (`bid`, `number`, `deposit_address`, `time_created`, `time_paid`, `win_chance`, `amount`, `profit`, `multiplier`, `time_expires`, `sender_address`, `status`) VALUES
(1, '21.74', '0', '1381975040', '0', '1', '1', '99', '100', '1382061440', '0', 'Pending'),
(2, '14.6', '0', '1381975042', '0', '1', '1', '99', '100', '1382061442', '0', 'Pending'),
(3, '76.57', '0', '1381975045', '0', '1', '1', '99', '100', '1382061445', '0', 'Pending'),
(4, '77.52', '1GgZS9KGtAcYFkB26EzvzHNhgvMyGMhTgp', '1381975207', '0', '1', '1', '99', '100', '1382061607', '0', 'Pending'),
(5, '99.28', '1XFv3vhPfyRUvRyYwcbXaP6NmjpYRD2ix', '1381975212', '0', '1', '1', '99', '100', '1382061612', '0', 'Pending'),
(6, '94.11', '1LBanP2Rw5RMfxNqQTsLE2JvFXkhSPMbae', '1381975960', '0', '50', '0.01', '0.01', '2', '1382062360', '', 'Pending'),
(7, '86.3', '17NNLNSHH2nwJcHm37SF2PGNNam8KXcaSR', '1381976296', '0', '50', '0.01', '0.01', '2', '1382062696', '', 'Pending'),
(8, '96.01', '1GrEtKBsDUS4TT4VXAztfmZHhyymWYSF11', '1381976330', '0', '50', '0.01', '0.01', '2', '1382062730', '', 'Pending'),
(9, '96.33', '1KUhGQ6Xma1hWHYfQHTjA6dkmMLMHJKhEV', '1381976349', '0', '50', '0.01', '0.01', '2', '1382062749', '', 'Pending'),
(10, '29.69', '1MbGm2ebTjF7BsgCBn4HovhPWVuoa5WaWA', '1381976422', '0', '50', '1', '1', '2', '1382062822', '', 'Pending'),
(11, '26.37', '17FPAnqEo6KBuaMdnr26tdwnuB8tEzJ9bp', '1381976473', '0', '50', '1', '1', '2', '1382062873', '', 'Pending');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
